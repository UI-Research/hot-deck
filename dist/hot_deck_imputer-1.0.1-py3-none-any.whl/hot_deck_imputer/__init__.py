"""
Intialization file necessary for the package to be recognized as a module. 

This can be empty.
"""
from .hot_deck_class import HotDeckImputer
from . import error_detection